/*
 * @Author: Marte
 * @Date:   2017-12-07 14:17:17
 * @Last Modified by:   Marte
 * @Last Modified time: 2018-01-15 21:07:58
 */
const STORAGE = 'STORAGE' //store增加首条
const ADDTO = 'ADDTO' //增加
const DELETE = 'DELETE' //删除
const INITIALIZATION = 'INITIALIZATION' //初始化数据
const SELECt = 'SELECt' //全选
const SELECt1 = 'SELECt1' //全选
const TOTAl = "TOTAl" //加总价
const TOTAl1 = "TOTAl1" //减总价
const SELECTTHTPRICE = "SELECTTHTPRICE" //全选总价
const SELECTTHTPRICE1 = "SELECTTHTPRICE1" //全选总价
const DONOTCHOOSE = "DONOTCHOOSE" //不选
const REMOVEITEM = "REMOVEITEM" //删除
export default {
  [STORAGE](state, id1) {
    state.shoppingData.push(id1);
  },
  [ADDTO](state, num) {
      state.shoppingData[num].numSum++
      state.shoppingData[num].total = state.shoppingData[num].numSum * state.shoppingData[num].Price
  },
  [DELETE](state, num) {
    if (state.shoppingData[num].numSum < 1) {
      return
    }
    state.shoppingData[num].numSum--
      state.shoppingData[num].total = state.shoppingData[num].numSum * state.shoppingData[num].Price
  },
  [INITIALIZATION](state) {
    for (let i = 0; i < state.shoppingData.length; i++) {
      state.shoppingData[i].total = state.shoppingData[i].numSum * state.shoppingData[i].Price
    }
  },
  [SELECt](state, status) {
    state.checkedAll = status;
    for (let i = 0; i < state.shoppingData.length; i++) {
      state.shoppingData[i].checked = status;
    }
  },
  [SELECt1](state, status) {
    state.checkedAll = status;
  },
  [TOTAl](state, itemPu) {
    // console.log(state.sumTotal);
    state.sumTotal=0;
      for (var i = 0; i < state.shoppingData.length; i++) {
// state.sumTotal = 0;
      state.sumTotal += state.shoppingData[i].total;
    }
    // state.sumTotal += itemPu.total;
    console.log(state.sumTotal);
    // itemPu.total=0;
  },
  [TOTAl1](state, itemPu) {
    state.sumTotal -= itemPu.total;
  },
  [SELECTTHTPRICE](state) {
    state.sumTotal=0;
    for (var i = 0; i < state.shoppingData.length; i++) {
// state.sumTotal = 0;
      state.sumTotal += state.shoppingData[i].total;
    }
  },
  [DONOTCHOOSE](state) {
    state.sumTotal = 0;
  },
  [REMOVEITEM](state, itemList) {
    //如果得不到索引，传递过来对象需要,检索到索引，然后删除
    // let index = 0;
    // index = state.shoppingData.indexOf(itemList);
    //直接传递过来索引
    state.shoppingData.splice(itemList, 1);
  },
  [SELECTTHTPRICE1](state, itemPu) {
    // console.log(itemPu);
    state.sumTotal += state.shoppingData[itemPu].total;
    console.log(state.sumTotal);
  },
}
