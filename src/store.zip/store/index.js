import Vue from 'vue'
import Vuex from 'vuex'
import mutations from './mutations'
import actions from './action'

Vue.use(Vuex)
const state = {
  shoppingData: localStorage["goodsList"] ? JSON.parse(localStorage["goodsList"]) : [], //商品信息
  sumTotal: 0, //总金额
  checkedAll: false //全选
}

export default new Vuex.Store({
  state,
  actions,
  mutations,
})
